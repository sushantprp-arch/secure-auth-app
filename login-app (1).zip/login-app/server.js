const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');

// --- tiny .env loader (no extra dependency) ---
try {
  fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n').forEach(l => {
    const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^"|"$/g, '');
  });
} catch (_) {}

const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data', 'users.json');
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

// ---------- storage (JSON file) ----------
const loadDB = () => { try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { return { users: [] }; } };
const saveDB = db => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

// ---------- helpers ----------
const norm = s => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
const findUser = (db, id) => { const k = norm(id); return db.users.find(u => u.username === k || u.email === k); };
const sessions = new Map();   // sid -> userId
const resetTokens = new Map(); // token -> { userId, exp }
const hits = new Map();        // simple rate limit

function limit(key, max, windowMs) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  arr.push(now); hits.set(key, arr);
  return arr.length > max;
}
const getCookie = (req, name) => {
  const m = (req.headers.cookie || '').match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
  return m ? decodeURIComponent(m[1]) : null;
};
const pwOk = p => typeof p === 'string' && p.length >= 6;

let transporter = null;
if (process.env.SMTP_HOST && process.env.SMTP_USER) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port: +(process.env.SMTP_PORT || 587),
    secure: +(process.env.SMTP_PORT) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

// ---------- app ----------
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', (req, res, next) => {
  if (limit('ip:' + req.ip, 60, 60 * 1000)) return res.status(429).json({ error: 'Too many requests. Please try again shortly.' });
  next();
});

// Register
app.post('/api/register', async (req, res) => {
  const { name, username, email, password, schoolName, dob } = req.body || {};
  if (![name, username, email, schoolName, dob].every(v => v && String(v).trim()))
    return res.status(400).json({ error: 'All fields are required.' });
  if (!/^[a-z0-9_.]{3,20}$/i.test(username)) return res.status(400).json({ error: 'Username must be 3–20 characters (letters, numbers, _ or .).' });
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (!pwOk(password)) return res.status(400).json({ error: 'Password must be at least 6 characters.' });

  const db = loadDB();
  if (db.users.some(u => u.username === norm(username))) return res.status(409).json({ error: 'This username is already taken.' });
  if (db.users.some(u => u.email === norm(email))) return res.status(409).json({ error: 'An account with this email already exists.' });

  db.users.push({
    id: crypto.randomUUID(),
    name: name.trim(),
    username: norm(username),
    email: norm(email),
    passwordHash: await bcrypt.hash(password, 10),
    schoolHash: await bcrypt.hash(norm(schoolName), 10),
    dobHash: await bcrypt.hash(String(dob).trim(), 10),
    otp: null,
    createdAt: new Date().toISOString()
  });
  saveDB(db);
  res.json({ ok: true, message: 'Account created. Please log in.' });
});

// Login
app.post('/api/login', async (req, res) => {
  const { identifier, password } = req.body || {};
  if (limit('login:' + norm(identifier), 8, 10 * 60 * 1000))
    return res.status(429).json({ error: 'Too many failed attempts. Try again in 10 minutes.' });
  const user = findUser(loadDB(), identifier);
  if (!user || !(await bcrypt.compare(String(password || ''), user.passwordHash)))
    return res.status(401).json({ error: 'Incorrect username/email or password.' });
  const sid = crypto.randomBytes(32).toString('hex');
  sessions.set(sid, user.id);
  res.setHeader('Set-Cookie', `sid=${sid}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400`);
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const uid = sessions.get(getCookie(req, 'sid'));
  const user = uid && loadDB().users.find(u => u.id === uid);
  if (!user) return res.status(401).json({ error: 'Not logged in.' });
  res.json({ name: user.name, username: user.username, email: user.email, createdAt: user.createdAt });
});

app.post('/api/logout', (req, res) => {
  sessions.delete(getCookie(req, 'sid'));
  res.setHeader('Set-Cookie', 'sid=; HttpOnly; Path=/; Max-Age=0');
  res.json({ ok: true });
});

// Forgot password — option 1: send OTP
app.post('/api/forgot/otp/send', async (req, res) => {
  const { identifier } = req.body || {};
  if (limit('otp:' + norm(identifier), 3, 10 * 60 * 1000))
    return res.status(429).json({ error: 'Too many OTP requests. Try again in 10 minutes.' });
  if (!transporter) return res.status(503).json({ error: 'Email service is not configured.' });
  const db = loadDB();
  const user = findUser(db, identifier);
  const generic = { ok: true, message: 'If the account exists, an OTP has been sent to its registered email.' };
  if (!user) return res.json(generic); // do not reveal whether an account exists

  const otp = String(crypto.randomInt(100000, 1000000));
  user.otp = { hash: await bcrypt.hash(otp, 8), exp: Date.now() + 5 * 60 * 1000, tries: 0 };
  saveDB(db);
  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER, to: user.email,
      subject: 'Your password reset code',
      text: `Your verification code is ${otp}. It expires in 5 minutes. Do not share it with anyone.`
    });
  } catch (e) {
    console.error('Email failed:', e.message);
    return res.status(502).json({ error: 'Unable to send email. Please try again later.' });
  }
  res.json(generic);
});

// option 1: verify OTP
app.post('/api/forgot/otp/verify', async (req, res) => {
  const { identifier, otp } = req.body || {};
  const db = loadDB();
  const user = findUser(db, identifier);
  const bad = () => res.status(400).json({ error: 'Invalid or expired OTP.' });
  if (!user || !user.otp) return bad();
  if (Date.now() > user.otp.exp || user.otp.tries >= 5) { user.otp = null; saveDB(db); return bad(); }
  user.otp.tries++;
  const ok = await bcrypt.compare(String(otp || '').trim(), user.otp.hash);
  if (!ok) { saveDB(db); return bad(); }
  user.otp = null; saveDB(db);
  const token = crypto.randomBytes(32).toString('hex');
  resetTokens.set(token, { userId: user.id, exp: Date.now() + 10 * 60 * 1000 });
  res.json({ ok: true, resetToken: token });
});

// Forgot password — option 2: security questions
app.post('/api/forgot/security', async (req, res) => {
  const { identifier, schoolName, dob } = req.body || {};
  if (limit('sec:' + norm(identifier), 5, 15 * 60 * 1000))
    return res.status(429).json({ error: 'Too many failed attempts. Try again in 15 minutes.' });
  const user = findUser(loadDB(), identifier);
  const bad = () => res.status(400).json({ error: 'The answers do not match our records.' });
  if (!user) return bad();
  const a = await bcrypt.compare(norm(schoolName), user.schoolHash);
  const b = await bcrypt.compare(String(dob || '').trim(), user.dobHash);
  if (!a || !b) return bad();
  const token = crypto.randomBytes(32).toString('hex');
  resetTokens.set(token, { userId: user.id, exp: Date.now() + 10 * 60 * 1000 });
  res.json({ ok: true, resetToken: token });
});

// Set new password
app.post('/api/forgot/reset', async (req, res) => {
  const { resetToken, newPassword } = req.body || {};
  const t = resetTokens.get(resetToken);
  if (!t || Date.now() > t.exp) return res.status(400).json({ error: 'Session expired. Please start again.' });
  if (!pwOk(newPassword)) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  const db = loadDB();
  const user = db.users.find(u => u.id === t.userId);
  user.passwordHash = await bcrypt.hash(newPassword, 10);
  saveDB(db);
  resetTokens.delete(resetToken);
  for (const [sid, uid] of sessions) if (uid === user.id) sessions.delete(sid);
  res.json({ ok: true, message: 'Password updated. Please log in.' });
});

if (!transporter) console.warn('\n⚠  SMTP not configured. Copy .env.example to .env and fill in SMTP details to enable OTP emails.');
app.listen(PORT, () => console.log(`\n✅ Server running: http://localhost:${PORT}\n`));
