const $ = s => document.querySelector(s);
const views = ['login', 'register', 'forgot', 'reset', 'dash'];
const msg = $('#msg');
let resetToken = null;

function show(name) {
  views.forEach(v => $('#view-' + v).hidden = v !== name);
  note('');
  const first = document.querySelector(`#view-${name} input`);
  if (first) first.focus();
}
function note(text, type = 'err') {
  msg.hidden = !text; msg.textContent = text; msg.className = 'msg ' + type;
}
async function api(url, body, method = 'POST') {
  const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: method === 'POST' ? JSON.stringify(body || {}) : undefined });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}
async function run(btn, fn) {
  if (btn) btn.disabled = true;
  try { await fn(); } catch (e) { note(e.message); } finally { if (btn) btn.disabled = false; }
}

document.querySelectorAll('[data-go]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); show(a.dataset.go); }));
document.querySelectorAll('[data-eye]').forEach(b => b.addEventListener('click', () => {
  const i = b.previousElementSibling; const hide = i.type === 'text';
  i.type = hide ? 'password' : 'text'; b.textContent = hide ? 'Show' : 'Hide';
}));

// Register
$('#view-register').addEventListener('submit', e => { e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  run(e.submitter, async () => {
    const r = await api('/api/register', d);
    e.target.reset(); show('login'); note(r.message, 'ok');
  });
});

// Login
$('#view-login').addEventListener('submit', e => { e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  run(e.submitter, async () => { await api('/api/login', d); e.target.reset(); await loadDash(); });
});

async function loadDash() {
  const u = await api('/api/me', null, 'GET');
  $('#d-name').textContent = u.name; $('#d-user').textContent = u.username;
  $('#d-email').textContent = u.email; $('#d-date').textContent = new Date(u.createdAt).toLocaleDateString('en-GB');
  show('dash');
}
$('#logout').addEventListener('click', () => run(null, async () => { await api('/api/logout'); show('login'); }));

// Forgot: tabs
document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === t));
  $('#tab-otp').hidden = t.dataset.tab !== 'otp';
  $('#tab-sec').hidden = t.dataset.tab !== 'sec';
  note('');
}));

// Forgot: OTP
$('#send-otp').addEventListener('click', e => run(e.target, async () => {
  const id = $('#f-id').value.trim(); if (!id) throw new Error('Enter your username or email first.');
  const r = await api('/api/forgot/otp/send', { identifier: id });
  $('#otp-box').hidden = false;
  note(r.message, 'ok'); $('#otp').focus();
}));
$('#tab-otp').addEventListener('submit', e => { e.preventDefault();
  run(e.submitter, async () => {
    const r = await api('/api/forgot/otp/verify', { identifier: $('#f-id').value, otp: $('#otp').value });
    resetToken = r.resetToken; show('reset');
  });
});

// Forgot: security answers
$('#tab-sec').addEventListener('submit', e => { e.preventDefault();
  run(e.submitter, async () => {
    const r = await api('/api/forgot/security', { identifier: $('#f-id').value, schoolName: $('#s-school').value, dob: $('#s-dob').value });
    resetToken = r.resetToken; show('reset');
  });
});

// Reset
$('#view-reset').addEventListener('submit', e => { e.preventDefault();
  run(e.submitter, async () => {
    const r = await api('/api/forgot/reset', { resetToken, newPassword: $('#new-pw').value });
    resetToken = null; $('#new-pw').value = ''; show('login'); note(r.message, 'ok');
  });
});

// Already logged in?
api('/api/me', null, 'GET').then(loadDash).catch(() => show('login'));
