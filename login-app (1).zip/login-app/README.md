# Login App

Register, sign in, and recover your password via email OTP or security questions.

## Run
1. Install Node.js 16+.
2. Copy `.env.example` to `.env` and fill in your SMTP details (Gmail: use an App Password).
3. In this folder run:
   ```
   npm install
   npm start
   ```
4. Open http://localhost:3000

## Features
- Registration with name, username, email, password and recovery details
- Sign in with username or email
- Password recovery: email OTP (6 digits, 5-minute expiry, 5 attempts) or previous school + date of birth
- Passwords, school name and date of birth are stored hashed (bcrypt) in `data/users.json`
- OTP is delivered by email only
